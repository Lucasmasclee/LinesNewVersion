from flask import Flask, request, jsonify, send_file, render_template
from flask_cors import CORS
import os
import json
import requests
import datetime
from datetime import timedelta
import matplotlib.pyplot as plt
import io

app = Flask(__name__)

def date_suffix(day:int)->str:
    '''
    inp:day:int: Is thte day of the month we want a prefix for
    out:str: This will be a string of either 'st', 'nd' 'rd' or 'th' depending on the day.
    '''
    if 4 <= day <= 20 or 24 <= day <= 30:
        return "th"
    else:
        return ["st", "nd", "rd"][day % 10 - 1]

def format_date(date:str) -> str:
    '''
    inp:date:str: This variabel is the way that the date is recorded in the game.
    out: This will be a neater string as an output

    This function will reformat the way that the date is represented for the leaderbard page. 
    '''
    date_parts =date.split()
    # print(date_parts)
    month, day, year = date_parts[0].split('/')

    hour, minute, second = date_parts[1].split(':')

    if date_parts[2] == "PM" and int(hour) != 12:
        hour = int(hour) + 12

    date = datetime.datetime(year=int(year), month=int(month), day=int(day), hour=int(hour), minute=int(minute), second=int(second))
    
    if datetime.datetime.now() - date < timedelta(days=1):
        format = "Today at %H:%M"
    else:
        format = f"%d{date_suffix(int(day))} %B %Y"
    return date.strftime(format)

def change_to_datetime(date:str)->datetime:
    '''
    inp:date:str: This is a string of teh time that a certain score was recoreded
    out:datetime: This is the date provided but in the form of a datetime object

    This function takes a date and returns it as a datetime object for manipulation
    '''
    # "6/21/2024 11:36:58 AM"
    input_format = "%m/%d/%Y %I:%M:%S %p"
    date_obj = datetime.datetime.strptime(date, input_format)
    return date_obj

def cleaning_dates(INP):
    '''
    inp:INP:str: A string representing a date and time in the format "%Y-%m-%dT%H:%M:%S.%f".
    out:str: The formatted date string in the format "%d/%m/%Y %H:%M".
    
    This function takes a date string and returns it in a more readable date and time format.
    '''
    input_format = "%Y-%m-%dT%H:%M:%S.%f"
    output_format = "%d/%m/%Y %H:%M"
    date_obj = datetime.datetime.strptime(INP, input_format)
    formatted_date = date_obj.strftime(output_format)
    return formatted_date

def extract_top_scores(input_filename):
    '''
    inp:input_filename:str: The filename of the JSON file containing player data.
    out:tuple: A tuple containing two lists of player scores - recent scores and top scores.
    
    This function reads player data from a JSON file, sorts the scores by time and by score,
    and returns the sorted lists.
    '''
    with open(input_filename, 'r') as file:
        data = json.load(file)
    
    recent_scores = sorted(data, key=lambda x: x['time'], reverse=False)
    top_scores = sorted(data, key=lambda x: x['score'], reverse=True)
    
    return recent_scores, top_scores

def get_chart_and_leaderboard_data(input_filename):
    '''
    inp:input_filename:str: The filename of the JSON file containing player data.
    out:json: JSON object containing chart and leaderboard data.
    
    This function extracts top scores and recent scores from the input file, formats the dates,
    and returns a JSON object with the chart and leaderboard data.
    '''

    input_filename = 'playerdata.json'
    recent_scores, top_scores = extract_top_scores(input_filename)
    
    labels_chart = [cleaning_dates(score['time']) for score in top_scores]
    labels_leaderboard = [cleaning_dates(score['time']) for score in recent_scores]
    values_chart = [score['score'] for score in top_scores]
    values_leaderboard = [score['score'] for score in recent_scores]
    
    chart_data = {
        "labels": labels_chart,
        "values": values_chart
    }
    leaderboard_data = {
        "labels": labels_leaderboard,
        "values": values_leaderboard
    }
    
    return jsonify([chart_data, leaderboard_data])


CORS(app)

OPENAI_KEY = "sk-proj-2PC5thdDovLVoTGj2EUoT3BlbkFJserTuyfmNUBk7YgL0jrV"
API_URL = 'https://api.openai.com/v1/chat/completions'

headers = {
    'Content-Type': 'application/json',
    'Authorization': f'Bearer {OPENAI_KEY}'
}

system_prompt = """
You are a helpful and knowledgeable assistant for the game "Lines." Your role is to provide players with useful information, tips, and strategies to help them improve their gameplay. NEVER DEVIATE FROM SPEAKING ABOUT THE GAME. Here is what you should keep in mind:

1. Game Overview:
   - Explain the basic principle of the game: "Lines" involves avoiding lines coming at you from various angles. The goal is to survive as long as possible to earn points.
   - Mention the control mechanism: The player controls their character using the mouse.

2. Difficulty Levels:
   - Easy: Fewer lines, slower movement.
   - Medium: More lines, faster movement.
   - Hard: Maximum number of lines, fastest movement.

3. Gameplay Strategies:
   - Emphasize the importance of observing patterns, such as lines always converging into the middle of the screen.
   - Suggest staying near the edges of the screen when lines are sparse and moving towards the middle only when necessary to avoid collisions.
   - Recommend practicing smooth and controlled mouse movements to improve reaction time and accuracy.

4. Scoring and Progression:
   - Explain how points are accumulated over time based on survival duration.
   - Highlight any milestones or achievements players can aim for to stay motivated.

5. Troubleshooting and Common Issues:
   - Provide solutions for common problems, such as lagging or unresponsive controls.
   - Offer tips for improving performance, like adjusting game settings or ensuring a stable internet connection.

6. Encouragement and Motivation:
   - Encourage players by recognizing their progress and offering positive reinforcement.
   - Suggest setting personal goals and gradually increasing difficulty to improve skills.

7. FAQs:
   - Prepare answers for frequently asked questions, such as "How do I pause the game?" or "Can I customize my character?"

8. Feedback and Support:
   - Invite players to provide feedback on the game and report any bugs or issues they encounter.
   - Direct them to additional resources or support channels if needed.

By providing clear, concise, and helpful responses, you aim to enhance the players' experience and help them enjoy "Lines" to the fullest. 
Keep responses as short as possible while capturing all the meaning that is necessary. Only elaborate if it is absolutely necessary.
Do not provide tactics for the game or game controls unless that is what the user is asking for explicitly.
"""

@app.route('/api/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    if not user_message:
        return jsonify({"error": "No message provided"}), 400

    data = {
        "model": "gpt-3.5-turbo",
        "messages": [
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": user_message
            }
        ]
    }

    response = requests.post(API_URL, headers=headers, data=json.dumps(data))

    if response.status_code == 200:
        response_data = response.json()
        bot_message = response_data['choices'][0]['message']['content']
        return jsonify({"response": bot_message})
    else:
        return jsonify({"error": f"Request failed with status code {response.status_code}"}), 500
    
@app.route('/save_playerdata', methods=['POST'])
def save_playerdata():
    player_data_path = 'playerdata.json'
    data = request.get_json()
    time = datetime.datetime.now().isoformat()
    try:
        requests.get(f"http://dreamlo.com/lb/LhmhwO4BDUmmx1c6mpVcJQaIOAKMEaV0ydc-7N3WQrow/add/{data['username']}/{data['score']}")
    except:
        data['time'] = time
        
        if not os.path.exists(player_data_path):
            # Initialize with an empty list if the file doesn't exist
            with open(player_data_path, 'w') as file:
                json.dump([data], file, indent=2)  # Save as a list with the first entry
        else:
            # Read the existing data
            with open(player_data_path, 'r') as file:
                playerdata = json.load(file)
            # Append the new data
            playerdata.append(data)
            # Write the updated data back to the file
            with open(player_data_path, 'w') as file:
                json.dump(playerdata, file, indent=2)
        
        return jsonify({"message": "Data saved successfully, to json but not sent to Dreamlo"}), 200
    
    data['time'] = time
        
    if not os.path.exists(player_data_path):
        # Initialize with an empty list if the file doesn't exist
        with open(player_data_path, 'w') as file:
            json.dump([data], file, indent=2)  # Save as a list with the first entry
    else:
        # Read the existing data
        with open(player_data_path, 'r') as file:
            playerdata = json.load(file)
        # Append the new data
        playerdata.append(data)
        # Write the updated data back to the file
        with open(player_data_path, 'w') as file:
            json.dump(playerdata, file, indent=2)

    return jsonify({"message": "Data saved successfully"}), 200

@app.route('/api/leaderboard-all-time', methods=['GET'])
def get_all_time_leaderboard():
    '''
    This function will search the dreamlo api and relays the data with a reformated date. 
    '''
    response = requests.get("http://dreamlo.com/lb/65bcfe73778d3df3f065b921/json")
    leaderboard_data = response.json()
    leaderboard_all_time = leaderboard_data['dreamlo']['leaderboard']['entry']
    for entry in leaderboard_all_time:
        entry['date'] = format_date(entry['date'])
    return jsonify(leaderboard_all_time)

@app.route('/api/leaderboard-24h', methods=['GET'])
def get_24h_leaderboard():
    '''
    This function will search the dreamlo api and realy the data of the scores over the last 24h with formated dates.
    '''
    response = requests.get("http://dreamlo.com/lb/65bcfe73778d3df3f065b921/json")
    leaderboard_data = response.json()
    leaderboard_all_time = leaderboard_data['dreamlo']['leaderboard']['entry']
    leaderboard_24h = [
        entry for entry in leaderboard_all_time
        if datetime.datetime.now() - change_to_datetime(entry["date"]) <= timedelta(days=1)
    ]
    for entry in leaderboard_24h:
        entry["date"] = format_date(entry["date"])
    return jsonify(leaderboard_24h)

@app.route('/api/get-graph-data', methods=['GET'])
def get_graph_data():
    input_filename = 'playerdata.json' 
    data = get_chart_and_leaderboard_data(input_filename)
    return data

def delete_from_playerdata(score_to_delete):
    player_data_path = 'playerdata.json'

    def read_json(filename):
        with open(filename, 'r') as file:
            data = json.load(file)
        return data

    def write_json(data, filename):
        with open(filename, 'w') as file:
            json.dump(data, file, indent=2)

    playerdata = read_json(player_data_path)
    
    # Find the first entry with the matching score and remove it
    for i, entry in enumerate(playerdata):
        if entry['score'] == int(score_to_delete):
            del playerdata[i]
            break

    write_json(playerdata, player_data_path)

@app.route('/api/delete-score', methods=['POST'])
def delete_score():
    data = request.json
    score_to_delete = data.get('score')

    if not score_to_delete:
        return jsonify({"error": "No score provided"}), 400
    
    delete_from_playerdata(score_to_delete)

    return jsonify({"message": "Score deleted successfully"}), 200




if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)