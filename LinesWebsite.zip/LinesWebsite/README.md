# Project Title
// IMAGE OF THE REAL FRONTEND
## Brief description of the project
The website our project group intends to build will be a website that hosts a game that is named LINES. The LINES
game is a game where the user has to use their mouse to avoid obstacles that if touched will end the game, the longer
the user survives the higher the score the user has at the end of the run. There will be 4 sites in total on the website.
The first will be a landing page where the user has the option to access all other pages via a menu. One of the options
in the menu will the the play option, when pressed a separate tab will be opened where the game will run. Below that
option will be the leaderboard option, where the user can view a leaderboard of the best runs along with statistics about
those performances. Below that option in the menu will be the personal statistics page where the user can view their
personal statistics on how they perform. Lastly, there will be a guide or help page, that will be aided by the chatGPT
API to provide the user with the best aid and support.
The statistics and information both about the leaderboard and the personal statistics about the user will be stored
and retrieved using the Dreamlo API. In order to use these APIs the front end will be written in HTML while the back
end will be written in Python.
## Frontend mockup
![Landing Page](./Read_me_files/Landing_page.png)
![Leaderboard](./Read_me_files/Leaderboard.png)
![Help Page](./Read_me_files/Help_page.png)
![Play Page](./Read_me_files/Play_page.png)    
![Phone Landing Page](./Read_me_files/Phone_landing_page.png)
![Phone Leaderboard](./Read_me_files/Phone_leaderboard.png)
![Phone Personal Statistics](./Read_me_files/Phone_personal_statistics.png)

## Team members
Terrence Semeleer, Vencel Kuba, Rohan Menon, Lucas Masclée
## Installation details
This website is  deployed on the web. This can be accesed with this link: https://lines-depolyed.onrender.com/

In order to use the link please follow the following steps:

For the installation of the dependancies run the command "pip install -r group_21_requirements.txt" in the enviornement. 
Then run both backend_server.py and server.py (frontend) simultaniously. 
Then follow the link given by the frontend server to access the game.

The code had to be altered and put into another repository in order to deploy the game on the web, the repository for this can be found here: https://github.com/rohanmenon04/deploy_web

**In order to see the personal statistics please play at least one game before hand**
## Architecture
High level structure of the repo
The architecture is two python servers running seperately each handling their own tasks. The frontend displays the server and calls the backend for data and information. The backend calls the data and handles the API's requrie for the running of the game. They are linked with RESTful architecture. The stucture can be seen in GitHub or the how folder are arranged if opened in an IDE.
![Architecture](./Read_me_files/importnat.png)
